TICTACTOE 

Creado por Jhon Ruiz

El Tic-Tac-Toe es un juego sencillo desarrollado con el módulo PyGame. Al comenzar, los jugadores deben presionar una tecla para iniciar el juego. El jugador "X" siempre empieza, y el turno se alterna automáticamente después de cada clic. Si hay un ganador o si el juego termina en empate, los jugadores pueden reiniciar la partida pulsando una tecla.

Aspectos clave que los estudiantes aprenderán:
    -Condicionales: Para verificar ganadores y manejar el flujo del juego.
    -Bucles: Para mantener el juego en ejecución.
    -Funciones: Para organizar la lógica del juego en secciones reutilizables.
    -Parámetros: Para pasar información a las funciones.
    -Archivos: Para posibles extensiones como guardar estadísticas del juego.
    -Lógica: Fundamentar las bases del razonamiento lógico que es esencial no solo en programación, sino también en la vida diaria.

Este proyecto puede parecer sencillo, pero ofrece una experiencia de aprendizaje rica y desafiante para los estudiantes que esten iniciando en el mundo de la programacion.